import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class PhoneCaseShopApp extends JFrame {
    
    // CardLayout components for navigation
    private CardLayout cardLayout;
    private JPanel mainPanel;
    
    private Map<String, String> userDatabase = new HashMap<>(); 
    private Map<String, String> cardDatabase = new HashMap<>();    
    private Map<String, String> addressDatabase = new HashMap<>(); 
    private String currentUser = null; // Tracks who is currently logged in
    
    // Shopping Cart Data
    private List<PhoneCase> shoppingCart = new ArrayList<>();
    private DefaultListModel<String> cartListModel = new DefaultListModel<>();
    private JList<String> cartList = new JList<>(cartListModel);
    private JLabel cartTotalLabel = new JLabel("Total: $0.00");

    // Dynamic catalog list replacing the old fixed array
    private final List<PhoneCase> products = new ArrayList<>();
    
    private JButton loginBtn; // Shared reference to update login state text across screens
    
    // Colour palette
    public static final Color THEME_BG = new Color(255, 255, 255); // White
    public static final Color THEME_LIGHT_PINK = Color.decode("#f5badd"); // Lighter Pink
    public static final Color THEME_HOT_PINK = Color.decode("#f092ca"); // Hot Pink
    public static final Color TEXT_DARK = new Color(50, 50, 50); // Charcoal for text
    
    public PhoneCaseShopApp() {
        setTitle("PinkElephant - Phone Case Shop");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize the cross-multiplied catalog
        initializeCatalog();

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        userDatabase.put("test", "test");
        cardDatabase.put("test", "1234-5678-9012-3456");
        addressDatabase.put("test", "123 Main St, Toronto, ON");

        // Add screens to the layout
        mainPanel.add(createMainMenuPanel(), "MainMenu");
        mainPanel.add(createShopPanel(), "Shop");
        mainPanel.add(createCartPanel(), "Cart");
        mainPanel.add(createRatingPanel(), "Rating");
        mainPanel.add(new FAQPanel(cardLayout, mainPanel), "FAQ");

        add(mainPanel);
        cardLayout.show(mainPanel, "MainMenu");
    }

    /**
     * Loops through all models and designs to ensure EVERY case is 
     * cross-generated and available for all devices.
     */
    private void initializeCatalog() {
        String[] phoneModels = {"iPhone 17", "iPhone 16", "Google Pixel 10 Pro", "Samsung Galaxy S26 Ultra"};

        // Base design definitions: {Category, Name, Price, Base Image Filename}
        String[][] designs = {
            // Patterns
            {"Pattern", "Polka Polka", "19.99", "polka.png"},
            {"Pattern", "Pink Stripes", "29.99", "stripes.png"},
            {"Pattern", "Sunset Gradient", "24.99", "sunset.png"},
            {"Pattern", "Black Lace (Clear)", "34.99", "lace.png"},
            {"Pattern", "Deer Fur", "22.99", "deer.png"},
            {"Pattern", "Paw-Fect Dog", "22.99", "dog.png"},
            // Solid Colors
            {"Solid Color", "Baby Pink", "15.99", "pink.png"},
            {"Solid Color", "White", "15.99", "white.png"},
            {"Solid Color", "Purple", "15.99", "purple.png"},
            {"Solid Color", "Beige", "15.99", "beige.png"},
            {"Solid Color", "Blue", "15.99", "blue.png"},
            {"Solid Color", "Teal", "15.99", "teal.png"},
            {"Solid Color", "Sunset Orange", "15.99", "orange.png"},
            {"Solid Color", "Mint Green", "15.99", "green.png"},
            {"Solid Color", "Black", "15.99", "black.png"}
        };

        // Generate the matrix combinations
        for (String model : phoneModels) {
            for (String[] design : designs) {
                products.add(new PhoneCase(
                    model, 
                    design[0], 
                    design[1], 
                    Double.parseDouble(design[2]), 
                    design[3]
                ));
            }
        }
    }

    // --- 1. MAIN MENU PANEL ---
    private JPanel createMainMenuPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(THEME_LIGHT_PINK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;

        JLabel title = new JLabel("Welcome to PinkElephant");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(new Color(33, 33, 33));
        gbc.gridy = 0;
        panel.add(title, gbc);

        JButton shopBtn = createStyledButton("Browse Shop");
        gbc.gridy = 1;
        panel.add(shopBtn, gbc);

        JButton cartBtn = createStyledButton("View Cart");
        gbc.gridy = 2;
        panel.add(cartBtn, gbc);

        JButton rateBtn = createStyledButton("Rate Us");
        gbc.gridy = 3;
        panel.add(rateBtn, gbc);
        
        JButton faqBtn = createStyledButton("FAQ");
        gbc.gridy = 4;
        panel.add(faqBtn, gbc);

        // Action Listeners
        shopBtn.addActionListener(e -> {
            if (currentUser != null) {
                loginBtn.setText("Hi, " + currentUser + " (Log Out)");
            } else {
                loginBtn.setText("Login / Register");
            }
            cardLayout.show(mainPanel, "Shop");
        });
        cartBtn.addActionListener(e -> {
            updateCartView();
            cardLayout.show(mainPanel, "Cart");
        });
        rateBtn.addActionListener(e -> cardLayout.show(mainPanel, "Rating"));
        faqBtn.addActionListener(e -> cardLayout.show(mainPanel, "FAQ"));

        return panel;
    }

    // --- 2. SHOP PANEL (DUAL DROPDOWN DYNAMIC FILTERING) ---
    private JPanel createShopPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(THEME_BG);
        
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(THEME_LIGHT_PINK);
        
        // Header Panel layout container for Title and both Filter JComboBoxes
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 5));
        headerPanel.setBackground(THEME_LIGHT_PINK);
        
        JLabel header = new JLabel("Select:");
        header.setFont(new Font("Arial", Font.BOLD, 14));
        header.setForeground(TEXT_DARK);
        headerPanel.add(header);
        
        // Dropdown filter selector 1: Phone Models
        String[] phoneModels = {"All Models", "iPhone 17", "iPhone 16", "Google Pixel 10 Pro", "Samsung Galaxy S26 Ultra"};
        JComboBox<String> modelFilterCombo = new JComboBox<>(phoneModels);
        modelFilterCombo.setFont(new Font("Arial", Font.PLAIN, 12));
        modelFilterCombo.setBackground(Color.WHITE);
        headerPanel.add(modelFilterCombo);
        
        // Dropdown filter selector 2: Aesthetic Design Styles
        String[] designCategories = {"All Styles", "Solid Colors", "Patterns and Designs"};
        JComboBox<String> categoryFilterCombo = new JComboBox<>(designCategories);
        categoryFilterCombo.setFont(new Font("Arial", Font.PLAIN, 12));
        categoryFilterCombo.setBackground(Color.WHITE);
        headerPanel.add(categoryFilterCombo);
        
        // Product display grid layout panel
        JPanel gridPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        gridPanel.setBackground(THEME_BG);
        gridPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    
        // Shared dynamic combination filtering logic
        ActionListener filterListener = e -> {
            String selectedModel = (String) modelFilterCombo.getSelectedItem();
            String selectedCategory = (String) categoryFilterCombo.getSelectedItem();
            
            gridPanel.removeAll();
            
            for (PhoneCase prod : products) {
                // Check Dropdown Rule 1: Phone Model Type
                boolean matchesModel = selectedModel.equals("All Models") || prod.phoneType.equals(selectedModel);
                
                // Check Dropdown Rule 2: Aesthetic Style Group
                boolean matchesCategory = false;
                if (selectedCategory.equals("All Styles")) {
                    matchesCategory = true;
                } else if (selectedCategory.equals("Solid Colors") && prod.designCategory.equals("Solid Color")) {
                    matchesCategory = true;
                } else if (selectedCategory.equals("Patterns and Designs") && prod.designCategory.equals("Pattern")) {
                    matchesCategory = true;
                }
                
                // Render card layout cell node only if it fits BOTH parameters simultaneously
                if (matchesModel && matchesCategory) {
                    JPanel itemPanel = new JPanel(new BorderLayout(5, 5));
                    itemPanel.setBorder(BorderFactory.createLineBorder(THEME_LIGHT_PINK, 2));
                    itemPanel.setBackground(Color.WHITE);
                    
                    JLabel imageLabel = new JLabel("", SwingConstants.CENTER);
                    try {
                        ImageIcon rawIcon = new ImageIcon(prod.imagePath);
                        if (rawIcon.getIconWidth() > 0) { 
                            Image scaledImg = rawIcon.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
                            imageLabel.setIcon(new ImageIcon(scaledImg));
                        } else {
                            imageLabel.setIcon(createPlaceholderIcon(prod.designType));
                        }
                    } catch (Exception ex) {
                        imageLabel.setIcon(createPlaceholderIcon(prod.designType));
                    }
                    itemPanel.add(imageLabel, BorderLayout.WEST); 
                    
                    JLabel details = new JLabel("<html><div style='padding:5px;'><b>" + prod.phoneType + "</b><br>" 
                                                + prod.designType + "<br><font color='green'>$" + prod.price + "</font></div></html>");
                    itemPanel.add(details, BorderLayout.CENTER);
    
                    JButton addToCartBtn = new JButton("Add to Cart");
                    addToCartBtn.setBackground(THEME_HOT_PINK);
                    addToCartBtn.setForeground(Color.WHITE);
                    addToCartBtn.setFont(new Font("Arial", Font.BOLD, 12));
                    addToCartBtn.setFocusPainted(false);
                    addToCartBtn.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
                    
                    addToCartBtn.addActionListener(evt -> {
                        shoppingCart.add(prod);
                        JOptionPane.showMessageDialog(this, prod.designType + " for " + prod.phoneType + " added to cart!");
                    });
                    itemPanel.add(addToCartBtn, BorderLayout.SOUTH);
    
                    gridPanel.add(itemPanel);
                }
            }
            
            gridPanel.revalidate();
            gridPanel.repaint();
        };
    
        // Hook action events up onto our shared state filtering method block
        modelFilterCombo.addActionListener(filterListener);
        categoryFilterCombo.addActionListener(filterListener);
    
        // Fire initialization call to draw items out immediately on layout bootstrap
        filterListener.actionPerformed(new ActionEvent(modelFilterCombo, ActionEvent.ACTION_PERFORMED, null));
        
        // Login State UI Controller button instantiation
        loginBtn = new JButton("Login / Register");
        loginBtn.setBackground(THEME_HOT_PINK);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
    
        loginBtn.addActionListener(e -> {
            if (currentUser != null) {
                int logoutConfirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Logout", JOptionPane.YES_NO_OPTION);
                if (logoutConfirm == JOptionPane.YES_OPTION) {
                    currentUser = null;
                    loginBtn.setText("Login / Register");
                    JOptionPane.showMessageDialog(this, "Logged out successfully!");
                }
            } else {
                LoginPage login = new LoginPage(this, userDatabase, cardDatabase, addressDatabase, loginBtn);
                login.setVisible(true);
                if (login.getLoggedInUser() != null) {
                    currentUser = login.getLoggedInUser();
                }
            }
        });
    
        topBar.add(headerPanel, BorderLayout.CENTER);
        topBar.add(loginBtn, BorderLayout.EAST);
        panel.add(topBar, BorderLayout.NORTH);
        
        JScrollPane scrollPane = new JScrollPane(gridPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JButton backBtn = createStyledButton("Back to Main Menu");
        panel.add(backBtn, BorderLayout.SOUTH);
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));
        
        return panel;
    }
    
    // Custom cell graphic rendering generator block if local assets fallback missing
    private ImageIcon createPlaceholderIcon(String text) {
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(120, 120, java.awt.image.BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g2.setColor(THEME_LIGHT_PINK); 
        g2.fillRect(0, 0, 120, 120);
        
        g2.setColor(THEME_HOT_PINK);
        g2.setFont(new Font("Arial", Font.BOLD, 12));
        String displayStr = text.length() > 10 ? text.substring(0, 10) + ".." : text;
        g2.drawString(displayStr, 15, 65);
        
        g2.dispose();
        return new ImageIcon(img);
    }

    // --- 3. SHOPPING CART & CHECKOUT PANEL ---
    private JPanel createCartPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setBackground(THEME_BG);

        JLabel header = new JLabel("Your Shopping Cart", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setForeground(TEXT_DARK);
        panel.add(header, BorderLayout.NORTH);
        
        cartList.setBackground(THEME_LIGHT_PINK);
        cartList.setFont(new Font("Arial", Font.PLAIN, 14));
        cartList.setSelectionBackground(THEME_HOT_PINK);
        cartList.setSelectionForeground(Color.WHITE);
        panel.add(new JScrollPane(cartList), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        bottomPanel.setBackground(THEME_BG);
        
        cartTotalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        cartTotalLabel.setForeground(THEME_HOT_PINK);
        cartTotalLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        bottomPanel.add(cartTotalLabel);

        JButton checkoutBtn = new JButton("Proceed to Checkout");
        checkoutBtn.setBackground(THEME_HOT_PINK); 
        checkoutBtn.setForeground(Color.WHITE);
        checkoutBtn.setFont(new Font("Arial", Font.BOLD, 14));
        checkoutBtn.setFocusPainted(false);
        checkoutBtn.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        
        checkoutBtn.addActionListener(e -> {
            if (shoppingCart.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Your cart is empty!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        
            JPanel checkoutForm = new JPanel(new GridLayout(0, 1, 5, 5));
            JTextField cardField = new JTextField(16);
            JTextField addressField = new JTextField(20);
        
            if (currentUser != null) {
                cardField.setText(cardDatabase.getOrDefault(currentUser, ""));
                addressField.setText(addressDatabase.getOrDefault(currentUser, ""));
                checkoutForm.add(new JLabel("Review Shipping & Payment (Logged in as " + currentUser + "):"));
            } else {
                checkoutForm.add(new JLabel("Checking out as Guest. Please fill in details below:"));
            }
        
            checkoutForm.add(new JLabel("Credit Card Number:"));
            checkoutForm.add(cardField);
            checkoutForm.add(new JLabel("Shipping Address:"));
            checkoutForm.add(addressField);
        
            int result = JOptionPane.showConfirmDialog(this, checkoutForm, 
                    "Checkout Form", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
            if (result != JOptionPane.OK_OPTION) return;
        
            String finalCard = cardField.getText().trim();
            String finalAddress = addressField.getText().trim();
        
            if (finalCard.isEmpty() || finalAddress.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Checkout failed! Credit card and shipping address are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        
            StringBuilder receiptDetails = new StringBuilder();
            receiptDetails.append("===============================\n");
            receiptDetails.append("         PINKELEPHANT          \n");
            receiptDetails.append("===============================\n\n");
            receiptDetails.append("Items Purchased:\n");
            
            double total = 0.0;
            for (PhoneCase prod : shoppingCart) {
                receiptDetails.append(String.format("- %s (%s) : $%.2f\n", prod.phoneType, prod.designType, prod.price));
                total += prod.price;
            }
            
            String maskedCard = (finalCard.length() > 4) 
                    ? "****-****-****-" + finalCard.substring(finalCard.length() - 4) 
                    : finalCard;
        
            receiptDetails.append("\n-------------------------------\n");
            receiptDetails.append(String.format("Total Charged: $%.2f\n", total));
            receiptDetails.append("-------------------------------\n");
            receiptDetails.append("Shipping To:\n").append(finalAddress).append("\n");
            receiptDetails.append("Payment Method: Card ending in ").append(maskedCard).append("\n");
            receiptDetails.append("===============================\n");
        
            JPanel receiptPanel = new JPanel(new BorderLayout(10, 10));
            receiptPanel.setPreferredSize(new Dimension(400, 350));
        
            JTextArea receiptTextArea = new JTextArea(receiptDetails.toString());
            receiptTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
            receiptTextArea.setEditable(false);
            receiptPanel.add(new JScrollPane(receiptTextArea), BorderLayout.CENTER);
        
            JPanel emailSection = new JPanel(new BorderLayout(5, 5));
            emailSection.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
            emailSection.add(new JLabel("Enter your email for a copy of the receipt:"), BorderLayout.NORTH);
            
            JTextField emailField = new JTextField();
            emailSection.add(emailField, BorderLayout.CENTER);
            
            receiptPanel.add(emailSection, BorderLayout.SOUTH);
        
            int finalOption = JOptionPane.showOptionDialog(
                this, 
                receiptPanel, 
                "Order Success - Receipt", 
                JOptionPane.OK_CANCEL_OPTION, 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                new Object[]{"Done & Send Email", "Close"}, 
                "Done & Send Email"
            );
        
            String enteredEmail = emailField.getText().trim();
            if (finalOption == 0 && !enteredEmail.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Receipt successfully emailed to: " + enteredEmail);
            } else if (finalOption == 0 && enteredEmail.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Order finalized without emailing a receipt.");
            }
        
            shoppingCart.clear();
            updateCartView();
            cardLayout.show(mainPanel, "MainMenu");
        });
        
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backBtn.setBackground(Color.WHITE);
        backBtn.setForeground(TEXT_DARK);
        backBtn.setFocusPainted(false);
        backBtn.setBorder(BorderFactory.createLineBorder(THEME_LIGHT_PINK, 1));
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));

        bottomPanel.add(checkoutBtn);
        bottomPanel.add(backBtn);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // --- 4. RATING PANEL ---
    private JPanel createRatingPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(THEME_LIGHT_PINK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;

        JLabel label = new JLabel("How would you rate your experience?");
        label.setFont(new Font("Arial", Font.BOLD, 18));
        label.setForeground(TEXT_DARK);
        gbc.gridy = 0;
        panel.add(label, gbc);

        String[] stars = {"⭐⭐⭐⭐⭐ (5/5)", "⭐⭐⭐⭐ (4/5)", "⭐⭐⭐ (3/5)", "⭐⭐ (2/5)", "⭐ (1/5)"};
        JComboBox<String> ratingCombo = new JComboBox<>(stars);
        ratingCombo.setBackground(Color.WHITE);
        ratingCombo.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridy = 1;
        panel.add(ratingCombo, gbc);

        JButton submitBtn = new JButton("Submit Rating");
        submitBtn.setFont(new Font("Arial", Font.BOLD, 14));
        submitBtn.setBackground(THEME_HOT_PINK);
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFocusPainted(false);
        submitBtn.setPreferredSize(new Dimension(180, 35));
        submitBtn.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        gbc.gridy = 2;
        panel.add(submitBtn, gbc);

        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backBtn.setBackground(Color.WHITE);
        backBtn.setForeground(TEXT_DARK);
        backBtn.setFocusPainted(false);
        backBtn.setPreferredSize(new Dimension(180, 35));
        backBtn.setBorder(BorderFactory.createLineBorder(THEME_LIGHT_PINK, 1));
        gbc.gridy = 3;
        panel.add(backBtn, gbc);

        submitBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Thank you for rating us " + ratingCombo.getSelectedItem() + "!");
            cardLayout.show(mainPanel, "MainMenu");
        });
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));

        return panel;
    }

    // --- HELPER METHODS ---
    private void updateCartView() {
        cartListModel.clear();
        double total = 0.0;
        for (PhoneCase prod : shoppingCart) {
            cartListModel.addElement(prod.phoneType + " - " + prod.designType + " ($" + prod.price + ")");
            total += prod.price;
        }
        cartTotalLabel.setText(String.format("Total: $%.2f", total));
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(240, 40));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(THEME_HOT_PINK); 
        button.setForeground(Color.WHITE); 
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        return button;
    }
    
    // Core data structure template class for items
    private static class PhoneCase {
        String phoneType;
        String designCategory; // Groups items inside "Solid Color" vs "Pattern" profiles
        String designType;
        double price;
        String imagePath;

        PhoneCase(String phoneType, String designCategory, String designType, double price, String imagePath) {
            this.phoneType = phoneType;
            this.designCategory = designCategory;
            this.designType = designType;
            this.price = price;
            this.imagePath = imagePath;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new PhoneCaseShopApp().setVisible(true);
        });
    }
}