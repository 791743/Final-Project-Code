import javax.swing.*;
import java.awt.*;

public class FAQPanel extends JPanel {
    
    public FAQPanel(CardLayout cardLayout, JPanel mainPanel) {
        // Match the application overall white/clean layout look
        setLayout(new BorderLayout(15, 15));
        setBackground(PhoneCaseShopApp.THEME_BG);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // --- HEADER TITLE ---
        JLabel title = new JLabel("Frequently Asked Questions", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(PhoneCaseShopApp.TEXT_DARK);
        // Add a little extra breathing room under the title
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        add(title, BorderLayout.NORTH);
        
        // --- FAQ CONTAINER SCROLL VIEW ---
        // Using a vertical BoxLayout container so items stack nicely from top to bottom
        JPanel faqContainer = new JPanel();
        faqContainer.setLayout(new BoxLayout(faqContainer, BoxLayout.Y_AXIS));
        faqContainer.setBackground(PhoneCaseShopApp.THEME_BG);
        
        // Populate the container with beautifully formatted Q&A blocks
        addFaqItem(faqContainer, "How do I add items to my cart?", 
                   "Click the 'Add to Cart' button found directly beneath any phone case design on the Shop page.");
        
        addFaqItem(faqContainer, "How do I checkout?", 
                   "Navigate to 'View Cart' from the main menu, review your items, and click the bright pink 'Proceed to Checkout' button.");

        addFaqItem(faqContainer, "What phone models do you support?", 
                   "We carry custom fits for the latest premium devices, including the iPhone 17 series, iPhone 16, Google Pixel 10 variants, and the Samsung Galaxy S26 lineup.");

        addFaqItem(faqContainer, "How does the login system work?", 
                   "You can click 'Login / Register' at the top right of the shopping page. Creating an account safely autofills your card and shipping data on your next visit!");

        // Wrap the FAQ container panel inside a clean custom ScrollPane
        JScrollPane scrollPane = new JScrollPane(faqContainer);
        scrollPane.setBorder(BorderFactory.createEmptyBorder()); // Removes ugly default borders
        scrollPane.getVerticalScrollBar().setUnitIncrement(12);  // Smooth scrolling experience
        add(scrollPane, BorderLayout.CENTER);
        
        // --- NAVIGATION FOOTER BUTTON ---
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setFont(new Font("Arial", Font.BOLD, 14));
        backBtn.setBackground(Color.WHITE);
        backBtn.setForeground(PhoneCaseShopApp.TEXT_DARK);
        backBtn.setFocusPainted(false);
        backBtn.setPreferredSize(new Dimension(backBtn.getPreferredSize().width, 40));
        backBtn.setBorder(BorderFactory.createLineBorder(PhoneCaseShopApp.THEME_LIGHT_PINK, 2));
        
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "MainMenu"));
        add(backBtn, BorderLayout.SOUTH);
    }  

    /**
     * Helper method to generate clean, individual styled item blocks dynamically
     */
    private void addFaqItem(JPanel container, String question, String answer) {
        JPanel itemPanel = new JPanel(new BorderLayout(5, 5));
        itemPanel.setBackground(PhoneCaseShopApp.THEME_LIGHT_PINK);
        // Gives each QA cell round padding and space away from neighbouring elements
        itemPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 10, 0, PhoneCaseShopApp.THEME_BG), // external separator gaps
                BorderFactory.createEmptyBorder(12, 14, 12, 14) // internal layout spacing
        ));
        
        // Build out nice text structures using simple, clean HTML rendering built into Swing components
        JLabel textLabel = new JLabel("<html>" +
                "<div style='color: #323232; font-family: Arial; font-size: 11pt;'><b>Q: " + question + "</b></div>" +
                "<div style='margin-top: 5px; color: #555555; font-family: Arial; font-size: 10pt;'>A: " + answer + "</div>" +
                "</html>");
        
        itemPanel.add(textLabel, BorderLayout.CENTER);
        
        // Ensure standard clean sizing bounds inside the container layout
        itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, itemPanel.getPreferredSize().height));
        container.add(itemPanel);
    }
}