import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

public class LoginPage extends JDialog {
    private Map<String, String> userDatabase;
    private Map<String, String> cardDatabase;
    private Map<String, String> addressDatabase;
    private JTextField userField;
    private JPasswordField passField;
    private JTextField regUserField;
    private JPasswordField regPassField;
    private JTextField regCardField;
    private JTextField regAddressField;
    private String loggedInUser = null;
    private JButton mainAccountBtn;

    public LoginPage(JFrame parent, Map<String, String> userDatabase,  Map<String, String> cardDatabase,
    Map<String, String> addressDatabase, JButton mainAccountBtn) {
        super(parent, "Welcome to PinkElephant", true);
        this.userDatabase = userDatabase;
        this.mainAccountBtn = mainAccountBtn;
        this.cardDatabase = cardDatabase;
        this.addressDatabase = addressDatabase;

        setSize(400, 480); // Increased height slightly to cleanly fit the close button
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        CardLayout dialogCardLayout = new CardLayout();
        JPanel dialogMainPanel = new JPanel(dialogCardLayout);

        // --- LOGIN VIEW ---
        JPanel loginView = new JPanel(new GridBagLayout());
        loginView.setBackground(PhoneCaseShopApp.THEME_LIGHT_PINK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel loginTitle = new JLabel("Log In", SwingConstants.CENTER);
        loginTitle.setFont(new Font("Arial", Font.BOLD, 22));
        loginTitle.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        loginView.add(loginTitle, gbc);
        
        gbc.gridwidth = 1;
        
        gbc.gridy = 1; gbc.gridx = 0; 
        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(PhoneCaseShopApp.TEXT_DARK);
        userLabel.setFont(new Font("Arial", Font.BOLD, 13));
        loginView.add(userLabel, gbc);
        
        userField = new JTextField(15);
        styleTextField(userField);
        gbc.gridx = 1; loginView.add(userField, gbc);

        gbc.gridy = 2; gbc.gridx = 0; 
        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(PhoneCaseShopApp.TEXT_DARK);
        passLabel.setFont(new Font("Arial", Font.BOLD, 13));
        loginView.add(passLabel, gbc);
        
        passField = new JPasswordField(15);
        styleTextField(passField);
        gbc.gridx = 1; loginView.add(passField, gbc);

        JButton submitLoginBtn = new JButton("Login");
        stylePrimaryButton(submitLoginBtn);
        gbc.gridy = 3; gbc.gridx = 0; gbc.gridwidth = 2;
        loginView.add(submitLoginBtn, gbc);

        JButton goToRegisterBtn = new JButton("Don't have an account? Register");
        styleLinkButton(goToRegisterBtn);
        gbc.gridy = 4;
        loginView.add(goToRegisterBtn, gbc);
        
        // Added Close Button for Login Screen
        JButton cancelLoginBtn = new JButton("Cancel & Close");
        styleSecondaryButton(cancelLoginBtn);
        gbc.gridy = 5;
        loginView.add(cancelLoginBtn, gbc);
        cancelLoginBtn.addActionListener(e -> dispose());
        
         // --- REGISTER VIEW ---
        JPanel registerView = new JPanel(new GridBagLayout());
        registerView.setBackground(PhoneCaseShopApp.THEME_LIGHT_PINK);
        GridBagConstraints gbcReg = new GridBagConstraints();
        gbcReg.insets = new Insets(6, 8, 6, 8);
        gbcReg.fill = GridBagConstraints.HORIZONTAL;

        JLabel regTitle = new JLabel("Create Account", SwingConstants.CENTER);
        regTitle.setFont(new Font("Arial", Font.BOLD, 22));
        regTitle.setForeground(Color.WHITE);
        gbcReg.gridx = 0; 
        gbcReg.gridy = 0; 
        gbcReg.gridwidth = 2;
        registerView.add(regTitle, gbcReg);

        gbcReg.gridwidth = 1;
        
        gbcReg.gridy = 1; gbcReg.gridx = 0; 
        JLabel regUserLabel = new JLabel("New Username:");
        regUserLabel.setForeground(PhoneCaseShopApp.TEXT_DARK);
        regUserLabel.setFont(new Font("Arial", Font.BOLD, 13));
        registerView.add(regUserLabel, gbcReg);
        
        regUserField = new JTextField(15);
        styleTextField(regUserField);
        gbcReg.gridx = 1; registerView.add(regUserField, gbcReg);

        gbcReg.gridy = 2; gbcReg.gridx = 0; 
        JLabel regPassLabel = new JLabel("New Password:");
        regPassLabel.setForeground(PhoneCaseShopApp.TEXT_DARK);
        regPassLabel.setFont(new Font("Arial", Font.BOLD, 13));
        registerView.add(regPassLabel, gbcReg);
        
        regPassField = new JPasswordField(15);
        styleTextField(regPassField);
        gbcReg.gridx = 1; registerView.add(regPassField, gbcReg);
        
        gbcReg.gridy = 3; gbcReg.gridx = 0;
        JLabel regCardLabel = new JLabel("Card Number:");
        regCardLabel.setForeground(PhoneCaseShopApp.TEXT_DARK);
        regCardLabel.setFont(new Font("Arial", Font.BOLD, 13));
        registerView.add(regCardLabel, gbcReg);
        
        regCardField = new JTextField(15);
        styleTextField(regCardField);
        gbcReg.gridx = 1; registerView.add(regCardField, gbcReg);
        
        gbcReg.gridy = 4; gbcReg.gridx = 0;
        JLabel regAddrLabel = new JLabel("Shipping Address:");
        regAddrLabel.setForeground(PhoneCaseShopApp.TEXT_DARK);
        regAddrLabel.setFont(new Font("Arial", Font.BOLD, 13));
        registerView.add(regAddrLabel, gbcReg);
        
        regAddressField = new JTextField(15);
        styleTextField(regAddressField);
        gbcReg.gridx = 1; registerView.add(regAddressField, gbcReg);
        
        JButton submitRegBtn = new JButton("Register");
        stylePrimaryButton(submitRegBtn);
        gbcReg.gridy = 5; gbcReg.gridx = 0; gbcReg.gridwidth = 2;
        registerView.add(submitRegBtn, gbcReg);

        JButton goToLoginBtn = new JButton("Already have an account? Login");
        styleLinkButton(goToLoginBtn);
        gbcReg.gridy = 6;
        registerView.add(goToLoginBtn, gbcReg);

        // Added Close Button for Registration Screen
        JButton cancelRegBtn = new JButton("Cancel & Close");
        styleSecondaryButton(cancelRegBtn);
        gbcReg.gridy = 7;
        registerView.add(cancelRegBtn, gbcReg);
        cancelRegBtn.addActionListener(e -> dispose());

        // Switch listeners
        goToRegisterBtn.addActionListener(e -> dialogCardLayout.show(dialogMainPanel, "RegisterCard"));
        goToLoginBtn.addActionListener(e -> dialogCardLayout.show(dialogMainPanel, "LoginCard"));

        // Register action
        submitRegBtn.addActionListener(e -> {
            String username = regUserField.getText().trim();
            String password = new String(regPassField.getPassword()).trim();
            String card = regCardField.getText().trim();
            String address = regAddressField.getText().trim();
            
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fields cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (userDatabase.containsKey(username)) {
                JOptionPane.showMessageDialog(this, "Username already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                userDatabase.put(username, password);
                if(card.isEmpty()) card = "No card saved";
                cardDatabase.put(username, card);
                if(address.isEmpty()) address = "No address saved";
                addressDatabase.put(username, address);
                
                JOptionPane.showMessageDialog(this, "Registered successfully! Please log in.");
                dialogCardLayout.show(dialogMainPanel, "LoginCard");
            }
        });

        // Login action
        submitLoginBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();
            
            if (userDatabase.containsKey(username) && userDatabase.get(username).equals(password)) {
                loggedInUser = username;
                mainAccountBtn.setText("Hi, " + loggedInUser + " (Log Out)");
                JOptionPane.showMessageDialog(this, "Welcome back, " + loggedInUser + "!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialogMainPanel.add(loginView, "LoginCard");
        dialogMainPanel.add(registerView, "RegisterCard");
        add(dialogMainPanel);
    }
    
    //Button Text Styling methods
    private void styleTextField(JTextField field){
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBackground(Color.WHITE);
        field.setForeground(PhoneCaseShopApp.TEXT_DARK);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE, 1),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)
        ));
    }
    
    private void stylePrimaryButton(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(PhoneCaseShopApp.THEME_HOT_PINK);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(button.getPreferredSize().width, 38));
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
    }

    private void styleLinkButton(JButton button) {
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.ITALIC + Font.BOLD, 12));
        button.setForeground(PhoneCaseShopApp.TEXT_DARK);
        
        // Subtle pink hover action effects for clean UI feedback
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setForeground(PhoneCaseShopApp.THEME_HOT_PINK);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setForeground(PhoneCaseShopApp.TEXT_DARK);
            }
        });
    }
    
    private void styleSecondaryButton(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setBackground(Color.WHITE);
        button.setForeground(PhoneCaseShopApp.TEXT_DARK);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(button.getPreferredSize().width, 32));
        button.setBorder(BorderFactory.createLineBorder(PhoneCaseShopApp.THEME_HOT_PINK, 1));
    }

    public String getLoggedInUser() {
        return loggedInUser;
    }
}